import mongoose from "mongoose";
const DBConnection = async () => {
  const DB_URL = `mongodb://user:virat123@ac-jyygf0w-shard-00-00.pjqxveu.mongodb.net:27017,ac-jyygf0w-shard-00-01.pjqxveu.mongodb.net:27017,ac-jyygf0w-shard-00-02.pjqxveu.mongodb.net:27017/?ssl=true&replicaSet=atlas-a9t4qe-shard-0&authSource=admin&retryWrites=true&w=majority`;
  try {
    await mongoose.connect(DB_URL, { useNewUrlParser: true });
    console.log("database connected successfully");
  } catch (error) {
    console.error("error while connecting", error.message);
  }
};

export default DBConnection;
